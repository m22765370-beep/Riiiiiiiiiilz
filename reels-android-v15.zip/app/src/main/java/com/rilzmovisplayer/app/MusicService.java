package com.rilzmovisplayer.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * سرویس پخش موزیک در پس‌زمینه.
 * خود صدا همچنان توسط WebView (تگ audio) پخش می‌شود؛ این سرویس فقط کارهای لازم را می‌کند تا اندروید
 * برنامه را وقتی از صفحه خارج شدی یا صفحه خاموش شد نکُشد/نخواباند:
 *  - فورگراند سرویس از نوع mediaPlayback + نوتیفیکیشن با دکمه‌های قبلی / پخش‌توقف / بعدی / بستن
 *  - MediaSession برای دکمه‌های هدفون و بلوتوث و کنترل روی صفحهٔ قفل
 *  - WakeLock نیمه‌روشن فقط وقتی واقعاً در حال پخش است
 */
public class MusicService extends Service {

    static final String CH = "music";
    static final int NID = 4711;
    static final String A_START = "com.rilzmovisplayer.app.MUSIC_START";
    static final String A_PLAY = "com.rilzmovisplayer.app.MUSIC_PLAY";
    static final String A_PAUSE = "com.rilzmovisplayer.app.MUSIC_PAUSE";
    static final String A_NEXT = "com.rilzmovisplayer.app.MUSIC_NEXT";
    static final String A_PREV = "com.rilzmovisplayer.app.MUSIC_PREV";
    static final String A_STOP = "com.rilzmovisplayer.app.MUSIC_STOP";
    /** اگر این‌قدر متوقف بماند، سرویس خودش بسته می‌شود (باتری). */
    private static final long IDLE_MS = 10 * 60 * 1000L;

    static volatile MusicService inst;
    private static volatile boolean sPlaying;
    private static volatile String sTitle = "";
    private static volatile String sArtist = "";

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable idleStop = new Runnable() { @Override public void run() { shutdown(); } };
    private PowerManager.WakeLock wl;
    private MediaSession ms;
    private boolean fg;

    // ------------------------------------------------------------ API برای MainActivity

    /** وضعیت جدید پخش از طرف صفحه. canStart: فقط وقتی برنامه جلوی چشم است اجازهٔ راه‌اندازی سرویس داریم. */
    static void post(Context c, boolean playing, String title, String artist, boolean canStart) {
        sPlaying = playing;
        sTitle = title == null ? "" : title;
        sArtist = artist == null ? "" : artist;
        MusicService s = inst;
        if (s != null) { s.refresh(); return; }
        if (!playing || !canStart) return;
        try {
            Intent i = new Intent(c, MusicService.class).setAction(A_START);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) { }
    }

    static void halt(Context c) {
        sPlaying = false;
        MusicService s = inst;
        if (s != null) { s.shutdown(); return; }
        try { c.stopService(new Intent(c, MusicService.class)); } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------ چرخهٔ حیات

    @SuppressWarnings("deprecation")
    @Override public void onCreate() {
        super.onCreate();
        inst = this;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CH, "پخش موزیک", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            ch.setSound(null, null);
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        try {
            ms = new MediaSession(this, "ReelsMusic");
            ms.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() { MainActivity.key("play"); }
                @Override public void onPause() { MainActivity.key("pause"); }
                @Override public void onSkipToNext() { MainActivity.key("next"); }
                @Override public void onSkipToPrevious() { MainActivity.key("prev"); }
                @Override public void onStop() { MainActivity.key("stop"); shutdown(); }
            });
            ms.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
            ms.setActive(true);
        } catch (Exception e) { ms = null; }
    }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        String a = in == null ? null : in.getAction();
        if (!fg) goForeground();
        if (a == null || A_START.equals(a)) { refresh(); }
        else if (A_PLAY.equals(a)) MainActivity.key("play");
        else if (A_PAUSE.equals(a)) MainActivity.key("pause");
        else if (A_NEXT.equals(a)) MainActivity.key("next");
        else if (A_PREV.equals(a)) MainActivity.key("prev");
        else if (A_STOP.equals(a)) { MainActivity.key("stop"); shutdown(); }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        h.removeCallbacks(idleStop);
        releaseWake();
        if (ms != null) { try { ms.setActive(false); ms.release(); } catch (Exception ignored) { } ms = null; }
        if (inst == this) inst = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------ کارهای داخلی

    private void goForeground() {
        Notification n = build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(NID, n);
            fg = true;
        } catch (Exception e) {
            // اگر اندروید اجازهٔ فورگراند نداد، سرویس را ببند تا کرش نکند
            stopSelf();
        }
    }

    void refresh() {
        updateSession();
        if (fg) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) { try { nm.notify(NID, build()); } catch (Exception ignored) { } }
        }
        h.removeCallbacks(idleStop);
        if (sPlaying) acquireWake(); else { releaseWake(); h.postDelayed(idleStop, IDLE_MS); }
    }

    void shutdown() {
        sPlaying = false;
        h.removeCallbacks(idleStop);
        releaseWake();
        try { stopForeground(true); } catch (Exception ignored) { }
        fg = false;
        stopSelf();
        if (inst == this) inst = null;
    }

    private void acquireWake() {
        try {
            if (wl == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm == null) return;
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "reels:music");
                wl.setReferenceCounted(false);
            }
            wl.acquire(4 * 60 * 60 * 1000L); // سقف ۴ ساعت؛ با هر تغییر آهنگ تمدید می‌شود
        } catch (Exception ignored) { }
    }

    private void releaseWake() {
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
    }

    private void updateSession() {
        if (ms == null) return;
        try {
            ms.setMetadata(new MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, sTitle.isEmpty() ? "ریلز" : sTitle)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, sArtist)
                    .build());
            long acts = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                    | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP;
            ms.setPlaybackState(new PlaybackState.Builder().setActions(acts)
                    .setState(sPlaying ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                            PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
        } catch (Exception ignored) { }
    }

    private Notification.Action act(int icon, String title, String action, int req) {
        PendingIntent pi = PendingIntent.getService(this, req,
                new Intent(this, MusicService.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build();
    }

    private Notification build() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        b.setSmallIcon(R.drawable.ic_stat_music)
                .setContentTitle(sTitle.isEmpty() ? "ریلز" : sTitle)
                .setContentText(sArtist.isEmpty() ? (sPlaying ? "در حال پخش موزیک" : "متوقف شد") : sArtist)
                .setContentIntent(open)
                .setOngoing(sPlaying)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        b.addAction(act(R.drawable.ic_prev, "قبلی", A_PREV, 1));
        b.addAction(sPlaying ? act(R.drawable.ic_pause, "توقف", A_PAUSE, 2) : act(R.drawable.ic_play, "پخش", A_PLAY, 2));
        b.addAction(act(R.drawable.ic_next, "بعدی", A_NEXT, 3));
        b.addAction(act(R.drawable.ic_close, "بستن", A_STOP, 4));
        Notification.MediaStyle st = new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2);
        if (ms != null) st.setMediaSession(ms.getSessionToken());
        b.setStyle(st);
        return b.build();
    }
}
