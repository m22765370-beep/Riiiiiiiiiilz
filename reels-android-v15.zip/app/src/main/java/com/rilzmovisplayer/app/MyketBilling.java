package com.rilzmovisplayer.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;

import com.android.vending.billing.IInAppBillingService;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** اتصال به سرویس پرداخت مایکت (همون پروتکل IAB v3). */
final class MyketBilling {

    interface Sink { void emit(JSONObject ev); }

    private interface Job { void run(IInAppBillingService s) throws Exception; }

    private static final class Pending {
        final Job job; final Runnable fail;
        Pending(Job j, Runnable f) { job = j; fail = f; }
    }

    static final int REQ_BUY = 7301;
    private static final String MARKET = "ir.mservices.market";
    private static final String BIND = "ir.mservices.market.InAppBillingService.BIND";
    private static final int API = 3;
    private static final String TYPE = "inapp";

    private final Activity act;
    private final Sink sink;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final List<Pending> waiting = new ArrayList<>();
    private IInAppBillingService svc;
    private boolean binding;

    MyketBilling(Activity a, Sink s) { act = a; sink = s; }

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            List<Pending> run;
            synchronized (MyketBilling.this) {
                svc = IInAppBillingService.Stub.asInterface(b);
                binding = false;
                run = new ArrayList<>(waiting);
                waiting.clear();
            }
            for (Pending p : run) exec(p);
        }
        @Override public void onServiceDisconnected(ComponentName n) {
            synchronized (MyketBilling.this) { svc = null; binding = false; }
        }
    };

    private void exec(final Pending p) {
        io.execute(new Runnable() {
            @Override public void run() {
                IInAppBillingService s;
                synchronized (MyketBilling.this) { s = svc; }
                if (s == null) { p.fail.run(); return; }
                try { p.job.run(s); }
                catch (Exception e) { error("ارتباط با مایکت برقرار نشد"); }
            }
        });
    }

    private void whenReady(Job job, Runnable fail) {
        Pending p = new Pending(job, fail);
        boolean needBind = false;
        synchronized (this) {
            if (svc != null) { exec(p); return; }
            waiting.add(p);
            if (!binding) { binding = true; needBind = true; }
        }
        if (needBind) {
            boolean ok = false;
            try {
                Intent i = new Intent(BIND);
                i.setPackage(MARKET);
                ok = act.bindService(i, conn, Context.BIND_AUTO_CREATE);
            } catch (Exception ignored) { }
            if (!ok) {
                List<Pending> failed;
                synchronized (this) {
                    binding = false;
                    failed = new ArrayList<>(waiting);
                    waiting.clear();
                }
                for (Pending f : failed) f.fail.run();
            }
        }
    }

    private void send(String type, String data, String sig, int code, String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            if (data != null) o.put("data", data);
            if (sig != null) o.put("signature", sig);
            o.put("code", code);
            if (msg != null) o.put("msg", msg);
            sink.emit(o);
        } catch (Exception ignored) { }
    }

    private void error(String msg) { send("error", null, null, -1, msg); }

    void purchase(final String sku, final String payload) {
        whenReady(new Job() {
            @Override public void run(IInAppBillingService s) throws Exception {
                int sup = s.isBillingSupported(API, act.getPackageName(), TYPE);
                if (sup != 0) { error("خرید درون‌برنامه‌ای در مایکت فعال نیست (کد " + sup + ")"); return; }
                Bundle b = s.getBuyIntent(API, act.getPackageName(), sku, TYPE, payload == null ? "" : payload);
                int rc = b == null ? 6 : b.getInt("RESPONSE_CODE", 6);
                if (rc == 7) { queryNow(s, "purchase"); return; }
                if (rc != 0) { error("خطا در شروع پرداخت (کد " + rc + ")"); return; }
                @SuppressWarnings("deprecation")
                final PendingIntent pi = b.getParcelable("BUY_INTENT");
                if (pi == null) { error("خطا در شروع پرداخت"); return; }
                act.runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try {
                            act.startIntentSenderForResult(pi.getIntentSender(), REQ_BUY, new Intent(), 0, 0, 0);
                        } catch (Exception e) { error("باز کردن صفحهٔ پرداخت ممکن نشد"); }
                    }
                });
            }
        }, new Runnable() {
            @Override public void run() { error("مایکت روی گوشی نصب نیست یا باید به‌روزرسانی بشه"); }
        });
    }

    void consume(final String token) {
        if (token == null || token.isEmpty()) return;
        whenReady(new Job() {
            @Override public void run(IInAppBillingService s) throws Exception {
                s.consumePurchase(API, act.getPackageName(), token);
            }
        }, new Runnable() { @Override public void run() { } });
    }

    void queryPurchases() {
        whenReady(new Job() {
            @Override public void run(IInAppBillingService s) throws Exception { queryNow(s, "restore"); }
        }, new Runnable() { @Override public void run() { } });
    }

    private void queryNow(IInAppBillingService s, String evType) throws Exception {
        String token = null;
        for (int guard = 0; guard < 10; guard++) {
            Bundle b = s.getPurchases(API, act.getPackageName(), TYPE, token);
            if (b == null || b.getInt("RESPONSE_CODE", 6) != 0) return;
            ArrayList<String> d = b.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
            ArrayList<String> g = b.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
            if (d != null) {
                for (int i = 0; i < d.size(); i++) {
                    send(evType, d.get(i), (g != null && i < g.size()) ? g.get(i) : null, 0, null);
                }
            }
            token = b.getString("INAPP_CONTINUATION_TOKEN");
            if (token == null) return;
        }
    }

    boolean onActivityResult(int req, int res, Intent data) {
        if (req != REQ_BUY) return false;
        if (data == null) {
            if (res == Activity.RESULT_CANCELED) send("cancel", null, null, 1, null);
            else error("پاسخی از مایکت دریافت نشد");
            return true;
        }
        int rc = data.getIntExtra("RESPONSE_CODE", 6);
        String pd = data.getStringExtra("INAPP_PURCHASE_DATA");
        String sig = data.getStringExtra("INAPP_DATA_SIGNATURE");
        if (res == Activity.RESULT_OK && rc == 0 && pd != null) {
            send("purchase", pd, sig, 0, null);
        } else if (res == Activity.RESULT_CANCELED || rc == 1) {
            send("cancel", null, null, 1, null);
        } else if (rc == 7) {
            whenReady(new Job() {
                @Override public void run(IInAppBillingService s) throws Exception { queryNow(s, "purchase"); }
            }, new Runnable() { @Override public void run() { } });
        } else {
            error("خطا در پرداخت (کد " + rc + ")");
        }
        return true;
    }

    void destroy() {
        try { act.unbindService(conn); } catch (Exception ignored) { }
        io.shutdown();
    }
}
