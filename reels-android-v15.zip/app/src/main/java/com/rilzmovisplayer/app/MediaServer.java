package com.rilzmovisplayer.app;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayDeque;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * سرور کوچک HTTP فقط روی 127.0.0.1 برای پخش ویدیو/آهنگ‌های گوشی.
 * پخش از طریق شبکهٔ اصلی کروم (Range واقعی، بدون جاوا بین راه) انجام می‌شه و خیلی پایدارتر از
 * shouldInterceptRequest ـه. مسیر شامل یک توکن تصادفی هر اجراست تا برنامهٔ دیگه‌ای نتونه فایل‌ها رو بخونه.
 */
final class MediaServer {

    interface Perm { boolean ok(boolean audio); }

    private static final ArrayDeque<String> LOG = new ArrayDeque<>();

    static void log(String m) {
        synchronized (LOG) {
            LOG.addLast(String.format(Locale.US, "%tT ", System.currentTimeMillis()) + m);
            while (LOG.size() > 160) LOG.removeFirst();
        }
    }

    static String dumpLog() {
        StringBuilder sb = new StringBuilder();
        synchronized (LOG) { for (String s : LOG) sb.append(s).append('\n'); }
        return sb.toString();
    }

    private final Context ctx;
    private final Perm perm;
    private final ServerSocket ss;
    private final String token;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean closed;

    MediaServer(Context c, Perm p) throws IOException {
        ctx = c;
        perm = p;
        ss = new ServerSocket(0, 64, InetAddress.getByAddress(new byte[]{127, 0, 0, 1}));
        byte[] r = new byte[12];
        new SecureRandom().nextBytes(r);
        StringBuilder sb = new StringBuilder();
        for (byte b : r) sb.append(String.format("%02x", b & 0xff));
        token = sb.toString();
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (!closed) {
                    try {
                        final Socket s = ss.accept();
                        pool.execute(new Runnable() { @Override public void run() { serve(s); } });
                    } catch (IOException e) {
                        if (closed) return;
                    }
                }
            }
        }, "media-server");
        t.setDaemon(true);
        t.start();
        log("server up on 127.0.0.1:" + ss.getLocalPort());
    }

    String base() { return "http://127.0.0.1:" + ss.getLocalPort() + "/" + token; }

    void close() {
        closed = true;
        try { ss.close(); } catch (IOException ignored) { }
        pool.shutdownNow();
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(128);
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') bo.write(c);
            if (bo.size() > 8192) throw new IOException("line too long");
        }
        if (c < 0 && bo.size() == 0) return null;
        return bo.toString("UTF-8");
    }

    private void head(OutputStream os, int code, String text, String mime, long len, String contentRange) throws IOException {
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(code).append(' ').append(text).append("\r\n");
        h.append("Content-Type: ").append(mime).append("\r\n");
        h.append("Accept-Ranges: bytes\r\n");
        h.append("Content-Length: ").append(len).append("\r\n");
        if (contentRange != null) h.append("Content-Range: ").append(contentRange).append("\r\n");
        h.append("Access-Control-Allow-Origin: *\r\n");
        h.append("Access-Control-Allow-Headers: Range\r\n");
        h.append("Access-Control-Expose-Headers: Content-Range, Content-Length, Accept-Ranges\r\n");
        h.append("Cache-Control: private, max-age=3600\r\n");
        h.append("Connection: close\r\n\r\n");
        os.write(h.toString().getBytes("UTF-8"));
    }

    private void serve(Socket s) {
        ParcelFileDescriptor pfd = null;
        String what = "?";
        long sent = 0;
        try {
            s.setSoTimeout(10000);
            s.setTcpNoDelay(true);
            InputStream in = s.getInputStream();
            OutputStream os = s.getOutputStream();
            String line = readLine(in);
            if (line == null) return;
            String range = null;
            String h;
            while ((h = readLine(in)) != null && h.length() > 0) {
                if (h.regionMatches(true, 0, "range:", 0, 6)) range = h.substring(6).trim();
            }
            s.setSoTimeout(0);
            String[] rl = line.split(" ");
            if (rl.length < 2) return;
            String method = rl[0];
            String path = rl[1];
            int q = path.indexOf('?');
            if (q >= 0) path = path.substring(0, q);
            what = method + " " + path.replace(token, "~");
            if ("OPTIONS".equals(method)) { head(os, 204, "No Content", "text/plain", 0, null); os.flush(); return; }
            String[] seg = path.split("/");
            if (seg.length < 3 || !token.equals(seg[1])) { head(os, 403, "Forbidden", "text/plain", 0, null); os.flush(); log("403 " + what); return; }
            if ("ping".equals(seg[2])) {
                byte[] gif = new byte[]{71,73,70,56,57,97,1,0,1,0,(byte)128,0,0,0,0,0,(byte)255,(byte)255,(byte)255,33,(byte)249,4,1,0,0,0,0,44,0,0,0,0,1,0,1,0,0,2,2,68,1,0,59};
                head(os, 200, "OK", "image/gif", gif.length, null);
                os.write(gif); os.flush();
                log("ping ok");
                return;
            }
            if (seg.length < 4) { head(os, 404, "Not Found", "text/plain", 0, null); os.flush(); return; }
            boolean vid = "v".equals(seg[2]);
            if (!perm.ok(!vid)) { head(os, 403, "Forbidden", "text/plain", 0, null); os.flush(); log("403 no permission " + what); return; }
            long id = Long.parseLong(seg[3]);
            Uri uri = ContentUris.withAppendedId(vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
            ContentResolver cr = ctx.getContentResolver();
            pfd = cr.openFileDescriptor(uri, "r");
            if (pfd == null) { head(os, 404, "Not Found", "text/plain", 0, null); os.flush(); log("404 open failed " + what); return; }
            long total = pfd.getStatSize();
            String mime = cr.getType(uri);
            if (mime == null || mime.length() == 0) mime = vid ? "video/mp4" : "audio/mpeg";
            long start = 0, end = total - 1;
            boolean partial = false;
            if (range != null && range.startsWith("bytes=") && total > 0) {
                String[] pr = range.substring(6).split(",")[0].split("-", 2);
                try {
                    String a = pr[0].trim(), b = pr.length > 1 ? pr[1].trim() : "";
                    if (a.isEmpty() && !b.isEmpty()) { start = Math.max(0, total - Long.parseLong(b)); }
                    else {
                        if (!a.isEmpty()) start = Long.parseLong(a);
                        if (!b.isEmpty()) end = Long.parseLong(b);
                    }
                } catch (NumberFormatException ignored) { }
                if (start >= total) {
                    head(os, 416, "Range Not Satisfiable", "text/plain", 0, "bytes */" + total);
                    os.flush(); log("416 " + what + " " + range); return;
                }
                if (end >= total) end = total - 1;
                partial = true;
            }
            long len = total > 0 ? end - start + 1 : Long.MAX_VALUE;
            if (partial) head(os, 206, "Partial Content", mime, len, "bytes " + start + "-" + end + "/" + total);
            else head(os, 200, "OK", mime, total > 0 ? len : 0, null);
            if (!"HEAD".equals(method)) {
                FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
                if (start > 0) fis.getChannel().position(start);
                byte[] buf = new byte[256 * 1024];
                long left = len;
                while (left > 0) {
                    int n = fis.read(buf, 0, (int) Math.min((long) buf.length, left));
                    if (n <= 0) break;
                    os.write(buf, 0, n);
                    sent += n;
                    left -= n;
                }
            }
            os.flush();
            log((partial ? "206 " : "200 ") + what + " " + (range == null ? "" : range + " ") + "sent=" + sent + " mime=" + mime);
        } catch (IOException e) {
            // قطع شدن اتصال توسط پخش‌کننده (رد کردن ویدیو / seek) عادیه
            log("closed " + what + " sent=" + sent + " (" + e.getClass().getSimpleName() + ")");
        } catch (Exception e) {
            log("ERR " + what + " " + e);
        } finally {
            if (pfd != null) try { pfd.close(); } catch (IOException ignored) { }
            try { s.close(); } catch (IOException ignored) { }
        }
    }
}
