-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.android.vending.billing.** { *; }
-keepattributes *Annotation*
