package com.rilzmovisplayer.app;

import android.annotation.SuppressLint;
import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Size;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/index.html";
    private static final int REQ_FILE = 7401;
    private static final int REQ_TREE = 7402;
    private static final int MODE_OPEN_FOLDER = 2;

    private FrameLayout root;
    private WebView web;
    private FrameLayout fsHolder;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private MyketBilling billing;
    private byte[] html;
    private int barTop = Color.parseColor("#070708");
    private int barBottom = Color.parseColor("#070708");
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private volatile long folderAt = 0;
    /** برای دکمه‌های نوتیفیکیشن/هدفون که از سرویس میان و باید به صفحه برسن */
    static volatile MainActivity self;
    private volatile boolean inFg = false;
    private volatile boolean musicPlaying = false;
    private boolean notifAsked = false;
    private final android.util.LruCache<String, byte[]> thumbCache = new android.util.LruCache<String, byte[]>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String k, byte[] v) { return v.length; }
    };
    private final java.util.concurrent.Semaphore thumbGate = new java.util.concurrent.Semaphore(2);

    // ---------------------------------------------------------------- lifecycle

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        self = this;
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        try { html = loadHtml(); } catch (Exception e) { html = ("<h1>Error</h1>").getBytes(); }

        root = new FrameLayout(this);
        root.setBackgroundColor(barTop);

        web = new WebView(this);
        web.setBackgroundColor(barTop);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        if (Build.VERSION.SDK_INT >= 26) web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        fsHolder = new FrameLayout(this);
        fsHolder.setBackgroundColor(Color.BLACK);
        fsHolder.setVisibility(View.GONE);
        root.addView(fsHolder, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        applyBars();
        installInsets();
        enterImmersive();

        WebView.setWebContentsDebuggingEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportMultipleWindows(false);
        if (Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(false);
        } else if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(WebSettings.FORCE_DARK_OFF);
        }

        billing = new MyketBilling(this, new MyketBilling.Sink() {
            @Override public void emit(final JSONObject ev) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (web != null) web.evaluateJavascript(
                                "window.onMyketBilling&&window.onMyketBilling(" + ev.toString() + ")", null);
                    }
                });
            }
        });
        web.addJavascriptInterface(new MyketJs(), "MyketBilling");
        web.addJavascriptInterface(new AppJs(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) {
                    String p = u.getPath();
                    if (p == null || p.equals("/") || p.equals("/index.html")) {
                        Map<String, String> h = new HashMap<>();
                        h.put("Cache-Control", "no-store");
                        return new WebResourceResponse("text/html", "UTF-8", 200, "OK", h,
                                new ByteArrayInputStream(html));
                    }
                    if (p != null && p.startsWith("/m/")) return serveMedia(r, p);
                    if (p != null && p.startsWith("/t/")) return serveThumb(p);
                    return notFound();
                }
                return null;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
                catch (ActivityNotFoundException ignored) { }
                return true;
            }
            @Override public void onPageStarted(WebView v, String url, android.graphics.Bitmap icon) {
                try { ourPage = HOST.equals(Uri.parse(url).getHost()); } catch (Exception e) { ourPage = false; }
            }
            @Override public void onPageFinished(WebView v, String url) {
                /* نوار‌های سیستم مخفی‌اند؛ دیگه نیازی به پولینگ رنگ (که لگ می‌ساخت) نیست */
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCb = cb;
                fsHolder.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fsHolder.setVisibility(View.VISIBLE);
                enterImmersive();
            }
            @Override public void onHideCustomView() { hideCustom(); }
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                return openChooser(cb, p);
            }
        });

        askMediaPermission();
        web.loadUrl(START_URL);
    }

    // ورودی «onPause» عمداً صدا نمی‌زنیم تا پخش موزیک با خاموش‌شدن صفحه قطع نشه.
    @Override protected void onResume() {
        super.onResume();
        inFg = true;
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("window.onAppResume&&window.onAppResume()", null);
        }
    }

    @Override protected void onStop() {
        super.onStop();
        inFg = false;
    }

    /** از سرویس موزیک (دکمهٔ نوتیفیکیشن، هدفون، بلوتوث) به صفحه فرمان می‌فرسته: play / pause / next / prev / stop */
    static void key(final String k) {
        final MainActivity a = self;
        if (a == null) return;
        a.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (a.web != null) a.web.evaluateJavascript("window.onMediaKey&&window.onMediaKey('" + k + "')", null);
            }
        });
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 7403 && web != null) web.evaluateJavascript("window.onMediaPerm&&window.onMediaPerm()", null);
    }

    @Override protected void onDestroy() {
        MusicService.halt(this);
        if (self == this) self = null;
        if (billing != null) billing.destroy();
        bg.shutdownNow();
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        enterImmersive();
    }

    @Override public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) enterImmersive();
    }

    @Override public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (web != null && web.canGoBack()) web.goBack();
        else leave();
    }

    /** خروج: اگه موزیک پخش می‌شه برنامه فقط می‌ره پس‌زمینه تا موزیک قطع نشه (با دکمهٔ «بستن» نوتیفیکیشن کامل بسته می‌شه). */
    private void leave() {
        if (musicPlaying) moveTaskToBack(true); else finish();
    }

    /** مجوز خوندن ویدیو/موسیقی (انتخاب‌گر خود اندروید بدون این هم کار می‌کنه، ولی دسترسی کامل‌تر می‌شه). */
    private void askMediaPermission() {
        if (Build.VERSION.SDK_INT < 23) return;
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.READ_MEDIA_VIDEO") != PackageManager.PERMISSION_GRANTED) need.add("android.permission.READ_MEDIA_VIDEO");
            if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) need.add("android.permission.READ_MEDIA_AUDIO");
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 7403);
    }

    /** وقتی کیبورد بالا میاد، صفحه بالا بره (چون حالت تمام‌صفحه adjustResize رو خنثی می‌کنه). */
    private void installInsets() {
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @SuppressWarnings("deprecation")
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                int bottom;
                if (Build.VERSION.SDK_INT >= 30) bottom = in.getInsets(WindowInsets.Type.ime()).bottom;
                else bottom = in.getSystemWindowInsetBottom();
                v.setPadding(0, 0, 0, bottom);
                return in;
            }
        });
    }

    // ---------------------------------------------------------------- لیست و پخش فایل‌های گوشی (MediaStore)

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private boolean mediaGranted(boolean audio) {
        if (Build.VERSION.SDK_INT < 23) return true;
        if (Build.VERSION.SDK_INT >= 33)
            return checkSelfPermission(audio ? "android.permission.READ_MEDIA_AUDIO" : "android.permission.READ_MEDIA_VIDEO") == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    /** لیست همهٔ ویدیوها یا آهنگ‌های گوشی به‌صورت JSON: [{i,n,s,d,m,t,f}] */
    private String queryMedia(boolean audio) {
        JSONArray arr = new JSONArray();
        Uri base = audio ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        String[] proj = {"_id", "_display_name", "_size", "duration", "mime_type", "date_added", "_data"};
        Cursor c = null;
        try {
            c = getContentResolver().query(base, proj, null, null, "date_added DESC");
            if (c == null) return "[]";
            while (c.moveToNext() && arr.length() < 6000) {
                long dur = c.getLong(3);
                String data = c.getString(6);
                String low = data == null ? "" : data.toLowerCase(Locale.ROOT);
                if (audio && ((dur > 0 && dur < 15000) || low.contains("/ringtones/") || low.contains("/notifications/") || low.contains("/alarms/"))) continue;
                String folder = "";
                if (data != null) {
                    File par = new File(data).getParentFile();
                    if (par != null) folder = par.getName();
                }
                JSONObject o = new JSONObject();
                o.put("i", c.getLong(0));
                o.put("n", c.getString(1));
                o.put("s", c.getLong(2));
                o.put("d", dur);
                o.put("m", c.getString(4));
                o.put("t", c.getLong(5));
                o.put("f", folder);
                arr.put(o);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    private static final class Lim extends InputStream {
        private final FileInputStream in;
        private final ParcelFileDescriptor pfd;
        private long left;
        Lim(FileInputStream in, ParcelFileDescriptor pfd, long left) { this.in = in; this.pfd = pfd; this.left = left; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }
        @Override public int read(byte[] b, int o, int l) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, o, (int) Math.min((long) l, left));
            if (n > 0) left -= n;
            return n;
        }
        @Override public void close() { try { pfd.close(); } catch (IOException ignored) { } }
    }

    /** /m/v/<id> یا /m/a/<id> : پخش مستقیم فایل با پشتیبانی از Range (برای جلو/عقب کردن). */
    private WebResourceResponse serveMedia(WebResourceRequest r, String p) {
        try {
            String[] seg = p.split("/");
            if (seg.length < 4) return notFound();
            boolean vid = "v".equals(seg[2]);
            if (!mediaGranted(!vid)) return notFound();
            long id = Long.parseLong(seg[3]);
            Uri uri = ContentUris.withAppendedId(vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd == null) return notFound();
            long total = pfd.getStatSize();
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = vid ? "video/mp4" : "audio/mpeg";
            String range = null;
            for (Map.Entry<String, String> e : r.getRequestHeaders().entrySet())
                if ("range".equalsIgnoreCase(e.getKey())) range = e.getValue();
            Map<String, String> h = new HashMap<>();
            h.put("Accept-Ranges", "bytes");
            h.put("Cache-Control", "no-store");
            FileInputStream fis = new FileInputStream(pfd.getFileDescriptor());
            if (total <= 0) {
                return new WebResourceResponse(mime, null, 200, "OK", h, new Lim(fis, pfd, Long.MAX_VALUE));
            }
            long start = 0, end = total - 1;
            boolean partial = false;
            if (range != null && range.startsWith("bytes=")) {
                String[] pr = range.substring(6).split("-", 2);
                try {
                    if (!pr[0].trim().isEmpty()) start = Long.parseLong(pr[0].trim());
                    if (pr.length > 1 && !pr[1].trim().isEmpty()) end = Long.parseLong(pr[1].trim());
                    if (pr[0].trim().isEmpty() && pr.length > 1 && !pr[1].trim().isEmpty()) { // bytes=-N
                        start = Math.max(0, total - Long.parseLong(pr[1].trim()));
                        end = total - 1;
                    }
                } catch (NumberFormatException ignored) { }
                if (start >= total) { pfd.close(); return notFound(); }
                if (end >= total) end = total - 1;
                partial = true;
            }
            if (start > 0) fis.getChannel().position(start);
            long len = end - start + 1;
            h.put("Content-Length", String.valueOf(len));
            if (partial) h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            return new WebResourceResponse(mime, null, partial ? 206 : 200, partial ? "Partial Content" : "OK", h, new Lim(fis, pfd, len));
        } catch (Exception e) {
            return notFound();
        }
    }

    /** /t/v/<id> یا /t/a/<id> : عکس بندانگشتی ویدیو / کاور آهنگ. */
    private WebResourceResponse serveThumb(String p) {
        boolean got = false;
        try {
            byte[] hit = thumbCache.get(p);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "max-age=86400");
            if (hit != null) return new WebResourceResponse("image/jpeg", null, 200, "OK", h, new ByteArrayInputStream(hit));
            thumbGate.acquire(); // حداکثر ۲ عکس هم‌زمان تا پخش ویدیو کند نشه
            got = true;
            hit = thumbCache.get(p);
            if (hit != null) return new WebResourceResponse("image/jpeg", null, 200, "OK", h, new ByteArrayInputStream(hit));
            String[] seg = p.split("/");
            if (seg.length < 4) return notFound();
            boolean vid = "v".equals(seg[2]);
            if (!mediaGranted(!vid)) return notFound();
            long id = Long.parseLong(seg[3]);
            Uri uri = ContentUris.withAppendedId(vid ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
            android.graphics.Bitmap bm = null;
            if (Build.VERSION.SDK_INT >= 29) {
                bm = getContentResolver().loadThumbnail(uri, new Size(180, 180), null);
            } else if (vid) {
                bm = MediaStore.Video.Thumbnails.getThumbnail(getContentResolver(), id, MediaStore.Video.Thumbnails.MINI_KIND, null);
            }
            if (bm == null) return notFound();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 78, bo);
            bm.recycle();
            byte[] out = bo.toByteArray();
            thumbCache.put(p, out);
            return new WebResourceResponse("image/jpeg", null, 200, "OK", h, new ByteArrayInputStream(out));
        } catch (Exception e) {
            return notFound();
        } finally {
            if (got) thumbGate.release();
        }
    }

    // ---------------------------------------------------------------- html (رمزگشایی در حافظه)

    private byte[] loadHtml() throws Exception {
        InputStream in = getAssets().open("app.dat");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        byte[] all = bo.toByteArray();
        byte[] k1 = hex(BuildConfig.K1), k2 = hex(BuildConfig.K2), key = new byte[16];
        for (int i = 0; i < 16; i++) key[i] = (byte) (k1[i] ^ k2[i]);
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(Arrays.copyOfRange(all, 0, 16)));
        return c.doFinal(all, 16, all.length - 16);
    }

    private static byte[] hex(String s) {
        byte[] o = new byte[s.length() / 2];
        for (int i = 0; i < o.length; i++) o[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16);
        return o;
    }

    // ---------------------------------------------------------------- انتخاب فایل / پوشه

    private boolean openChooser(ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams p) {
        if (fileCb != null) fileCb.onReceiveValue(null);
        fileCb = cb;
        try {
            boolean folder = p.getMode() == MODE_OPEN_FOLDER || (System.currentTimeMillis() - folderAt < 3000);
            folderAt = 0;
            if (folder) {
                Intent ti = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                ti.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                startActivityForResult(ti, REQ_TREE);
            } else {
                startActivityForResult(p.createIntent(), REQ_FILE);
            }
        } catch (Exception e) {
            fileCb = null;
            cb.onReceiveValue(null);
        }
        return true;
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (billing != null && billing.onActivityResult(req, res, data)) return;
        if (req == REQ_FILE) {
            ValueCallback<Uri[]> cb = fileCb;
            fileCb = null;
            if (cb != null) cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
        } else if (req == REQ_TREE) {
            final ValueCallback<Uri[]> cb = fileCb;
            fileCb = null;
            if (cb == null) return;
            if (res != RESULT_OK || data == null || data.getData() == null) { cb.onReceiveValue(null); return; }
            final Uri tree = data.getData();
            try { getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
            Toast.makeText(this, "در حال خواندن پوشه…", Toast.LENGTH_SHORT).show();
            bg.execute(new Runnable() {
                @Override public void run() {
                    final List<Uri> out = new ArrayList<>();
                    try {
                        collect(getContentResolver(), tree, DocumentsContract.getTreeDocumentId(tree), out, 0);
                    } catch (Exception ignored) { }
                    runOnUiThread(new Runnable() {
                        @Override public void run() { cb.onReceiveValue(out.toArray(new Uri[0])); }
                    });
                }
            });
        }
    }

    private static void collect(ContentResolver cr, Uri tree, String docId, List<Uri> out, int depth) {
        if (depth > 8 || out.size() >= 5000) return;
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        Cursor c = null;
        try {
            c = cr.query(kids, new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c == null) return;
            while (c.moveToNext() && out.size() < 5000) {
                String id = c.getString(0), mime = c.getString(1), name = c.getString(2);
                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    collect(cr, tree, id, out, depth + 1);
                } else if (isMedia(mime, name)) {
                    out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
    }

    private static boolean isMedia(String mime, String name) {
        if (mime != null && (mime.startsWith("video/") || mime.startsWith("audio/") || mime.equals("application/ogg"))) return true;
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        String[] ext = {".mp4", ".mkv", ".webm", ".mov", ".m4v", ".3gp", ".mp3", ".m4a", ".aac", ".wav", ".ogg", ".opus", ".flac"};
        for (String e : ext) if (n.endsWith(e)) return true;
        return false;
    }

    // ---------------------------------------------------------------- تمام‌صفحه و نوار‌های سیستم

    private void hideCustom() {
        if (customView == null) return;
        fsHolder.removeView(customView);
        fsHolder.setVisibility(View.GONE);
        customView = null;
        if (customCb != null) { customCb.onCustomViewHidden(); customCb = null; }
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        enterImmersive();
    }

    @SuppressWarnings("deprecation")
    private void enterImmersive() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(android.view.WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @SuppressWarnings("deprecation")
    private void exitImmersive() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
            w.setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(true);
            WindowInsetsController c = w.getInsetsController();
            if (c != null) c.show(android.view.WindowInsets.Type.systemBars());
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
        applyBars();
    }

    private static boolean isLight(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.6;
    }

    @SuppressWarnings("deprecation")
    private void applyBars() {
        if (customView != null) return;
        Window w = getWindow();
        w.setStatusBarColor(barTop);
        w.setNavigationBarColor(barBottom);
        root.setBackgroundColor(barTop);
        boolean lt = isLight(barTop), lb = isLight(barBottom);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.setSystemBarsAppearance(lt ? WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS : 0,
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
                c.setSystemBarsAppearance(lb ? WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS : 0,
                        WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        } else {
            int f = w.getDecorView().getSystemUiVisibility();
            if (Build.VERSION.SDK_INT >= 23) {
                f = lt ? (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
            if (Build.VERSION.SDK_INT >= 26) {
                f = lb ? (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            }
            w.getDecorView().setSystemUiVisibility(f);
        }
    }

    private static final Pattern RGB = Pattern.compile("rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)(?:,\\s*([\\d.]+))?\\)");

    private static int parseColor(String s, int fallback) {
        if (s == null) return fallback;
        Matcher m = RGB.matcher(s);
        if (!m.find()) return fallback;
        try {
            if (m.group(4) != null && Float.parseFloat(m.group(4)) < 0.5f) return fallback;
            return Color.rgb(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)), Integer.parseInt(m.group(3)));
        } catch (Exception e) { return fallback; }
    }

    /** رنگ نوار بالا/پایین گوشی رو با رنگ پس‌زمینهٔ صفحه هماهنگ می‌کنه. */
    private static final String BARS_JS =
            "(function(){if(window.__barsHooked)return;window.__barsHooked=true;"
          + "function bg(x,y){var e=document.elementFromPoint(x,y);"
          + "while(e){var c=getComputedStyle(e).backgroundColor;"
          + "if(c&&c!=='transparent'&&!/rgba\\(\\s*0,\\s*0,\\s*0,\\s*0\\s*\\)/.test(c))return c;e=e.parentElement}"
          + "return getComputedStyle(document.body).backgroundColor}"
          + "var last='';function tick(){try{var t=bg(4,4),b=bg(4,innerHeight-4),k=t+'|'+b;"
          + "if(k!==last){last=k;if(window.AndroidApp&&AndroidApp.setBars)AndroidApp.setBars(t,b)}}catch(e){}}"
          + "setInterval(tick,600);tick()})();";

    // ---------------------------------------------------------------- پل‌های جاوااسکریپت

    private volatile boolean ourPage = false;

    private boolean fromOurPage() { return ourPage; }

    private final class MyketJs {
        @JavascriptInterface public void purchase(String sku, String payload) {
            if (fromOurPage()) billing.purchase(sku, payload);
        }
        @JavascriptInterface public void consume(String token) {
            if (fromOurPage()) billing.consume(token);
        }
        @JavascriptInterface public void queryPurchases() {
            if (fromOurPage()) billing.queryPurchases();
        }
    }

    private final class AppJs {
        @JavascriptInterface public boolean hasMedia(String kind) {
            return mediaGranted("a".equals(kind));
        }
        @JavascriptInterface public void requestMedia() {
            if (!fromOurPage()) return;
            runOnUiThread(new Runnable() { @Override public void run() { askMediaPermission(); } });
        }
        @JavascriptInterface public String listMedia(String kind) {
            if (!fromOurPage()) return "[]";
            boolean a = "a".equals(kind);
            return mediaGranted(a) ? queryMedia(a) : "[]";
        }
        @JavascriptInterface public void openSettings() {
            if (!fromOurPage()) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                        startActivity(i);
                    } catch (Exception ignored) { }
                }
            });
        }
        @JavascriptInterface public void folderNext() {
            if (!fromOurPage()) return;
            folderAt = System.currentTimeMillis();
        }
        @JavascriptInterface public void exit() {
            if (!fromOurPage()) return;
            runOnUiThread(new Runnable() { @Override public void run() { leave(); } });
        }
        /** وضعیت پخش موزیک رو از صفحه می‌گیره و نوتیفیکیشن/سرویس پس‌زمینه رو به‌روز می‌کنه. */
        @JavascriptInterface public void musicState(final boolean playing, final String title, final String artist) {
            if (!fromOurPage()) return;
            musicPlaying = playing;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (playing && Build.VERSION.SDK_INT >= 33 && !notifAsked
                            && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        notifAsked = true;
                        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7404);
                    }
                    MusicService.post(MainActivity.this, playing, title, artist, inFg);
                }
            });
        }
        @JavascriptInterface public void musicStop() {
            if (!fromOurPage()) return;
            musicPlaying = false;
            runOnUiThread(new Runnable() { @Override public void run() { MusicService.halt(MainActivity.this); } });
        }
        @JavascriptInterface public void setBars(final String top, final String bottom) {
            if (!fromOurPage()) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    barTop = parseColor(top, barTop);
                    barBottom = parseColor(bottom, barBottom);
                    applyBars();
                }
            });
        }
        @JavascriptInterface public void toggleRotate() {
            if (!fromOurPage()) return;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
                    setRequestedOrientation(land ? ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                            : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                }
            });
        }
        @JavascriptInterface public void unlockRotate() {
            if (!fromOurPage()) return;
            runOnUiThread(new Runnable() {
                @Override public void run() { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); }
            });
        }
    }
}
