# ریلز – پروژهٔ اندروید (WebView + خرید مایکت)

نام بسته: `com.rilzmovisplayer.app`

## بیلد با گیت‌هاب
1. یک مخزن (Repository) جدید بساز و **همهٔ محتویات این پوشه** را آپلود کن (پوشهٔ مخفی `.github` هم باید باشد).
2. تب **Actions** ← workflow به نام **Build APK** ← اجرا می‌شود (یا Run workflow).
3. بعد از چند دقیقه از پایین صفحهٔ اجرا، فایل **reels-apk** (داخلش `app-release.apk`) را دانلود کن.

## مایکت
- شناسهٔ محصول (SKU): `coins_10000` — نوع: **مصرفی (Consumable)** — قیمت: ۱۰٬۰۰۰ تومان (۱۰٬۰۰۰ سکه)
- کلید عمومی RSA و نام بسته داخل `html-src/index.html` تنظیم شده‌اند.

## تغییر دادن چیزها
- **خود برنامه (HTML):** فایل `html-src/index.html` را عوض کن و دوباره بیلد بگیر. موقع بیلد، رمزنگاری می‌شود و داخل APK فقط `assets/app.dat` (رمز‌شده) هست.
- **آیکن:** فایل‌های `app/src/main/res/mipmap-*/ic_launcher*.png` و برای اندروید ۸+ فایل `res/drawable/ic_launcher_foreground.xml` و رنگ `ic_launcher_background` در `res/values/colors.xml`.
- **نام برنامه:** `app/src/main/res/values/strings.xml`
- **نسخه:** `versionCode` و `versionName` در `app/build.gradle` (برای هر آپدیت در مایکت باید `versionCode` بیشتر شود).

## امضا
APK با کلید debug امضا می‌شود تا قابل نصب باشد. برای انتشار در مایکت با کلید خودت دوباره امضایش کن و برای همیشه همان کلید را نگه دار.

## دسترسی‌ها
فقط `INTERNET` و مجوز پرداخت مایکت (`ir.mservices.market.BILLING`؛ بدون آن خرید درون‌برنامه‌ای کار نمی‌کند). دسترسی به حافظه لازم نیست؛ فایل‌ها با انتخاب‌گر خود اندروید باز می‌شوند.
